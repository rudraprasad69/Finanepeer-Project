<!--

 # FinancepeerAssignment

# Project Title and Description
    I have done thid project.
    In this project there are two part.
    1. Frontend    2. Backend 

    1. Frontend
        In frontend I have made
            => An authencation system i.e 
                Signup page
                login page 
                logout 

            => then I upload the json file which i received in the assignment in mongodb database
                after that i fetch this json file throught api and show in tabular form in frontend. 

    2. Backend
        In backend I have made some api :
            => to create user
            => to login user
            => to show all fetch data
            => also i hashed the password
        
        and i connectmy backend with mongodb database

# Installation and Usage

    To install first we download the project from github link. 
    after that extract it. then oen it in any ide. 
    after open we need to first type command 'npm install' in seperate frontend and backend both part
    npm install command install all the required packages that i used.

    In backend config file i use my mongodb databse link.
        so it is recommended to you please please setup you mongodb database as required.
    

    after that you go backend folder 'cd  .\backend\' and then  type 'nodemon .\index.js'
    same you go frontent part 'cd .\assignment_f1rontent_part' and then type 'npm start' 
 -->
