const config = {
    db : {
        url: "127.0.0.1:27017",
        name: "registration_Data"
    }
}

module.exports = config;